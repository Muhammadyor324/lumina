
import React, { useEffect, useState, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { GEMINI_LIVE_MODEL, SYSTEM_INSTRUCTION } from '../constants';
import { decode, decodeAudioData, createBlob } from '../utils/audio';

interface VideoCallOverlayProps {
  onEndCall: () => void;
  avatarUrl?: string;
  loveLevel: number;
  mood?: string;
}

const VideoCallOverlay: React.FC<VideoCallOverlayProps> = ({ onEndCall, avatarUrl, loveLevel, mood = 'happy' }) => {
  const [status, setStatus] = useState('CONNECTING...');
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraFront, setIsCameraFront] = useState(true);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [callDuration, setCallDuration] = useState(0);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<any>(null);
  const audioContextInRef = useRef<AudioContext | null>(null);
  const audioContextOutRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const frameIntervalRef = useRef<number | null>(null);

  // Dynamic Waveform Refinement
  const [waveHeights, setWaveHeights] = useState<number[]>(new Array(24).fill(15));

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const setupCamera = async () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(t => t.stop());
    }
    const constraints = {
      video: { facingMode: isCameraFront ? 'user' : 'environment' },
      audio: true
    };
    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (videoRef.current) videoRef.current.srcObject = stream;
      return stream;
    } catch (e) {
      return null;
    }
  };

  useEffect(() => {
    let waveInterval: any;
    if (isModelSpeaking) {
      waveInterval = setInterval(() => {
        setWaveHeights(prev => prev.map(() => 15 + Math.random() * 85));
      }, 80);
    } else {
      setWaveHeights(prev => prev.map(h => Math.max(15, h * 0.8)));
    }
    return () => clearInterval(waveInterval);
  }, [isModelSpeaking]);

  useEffect(() => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    audioContextInRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    audioContextOutRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

    const startLiveSession = async () => {
      const stream = await setupCamera();
      if (!stream) { onEndCall(); return; }

      try {
        const sessionPromise = ai.live.connect({
          model: GEMINI_LIVE_MODEL,
          callbacks: {
            onopen: () => {
              setStatus('LIVE');
              const source = audioContextInRef.current!.createMediaStreamSource(stream);
              const scriptProcessor = audioContextInRef.current!.createScriptProcessor(4096, 1, 1);
              scriptProcessor.onaudioprocess = (e) => {
                if (isMuted) return;
                const inputData = e.inputBuffer.getChannelData(0);
                sessionPromise.then(session => session.sendRealtimeInput({ media: createBlob(inputData) }));
              };
              source.connect(scriptProcessor);
              scriptProcessor.connect(audioContextInRef.current!.destination);

              frameIntervalRef.current = window.setInterval(() => {
                if (videoRef.current && canvasRef.current) {
                  const ctx = canvasRef.current.getContext('2d');
                  if (ctx) {
                    canvasRef.current.width = 320;
                    canvasRef.current.height = 240;
                    ctx.drawImage(videoRef.current, 0, 0, 320, 240);
                    canvasRef.current.toBlob(blob => {
                      if (blob) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          const base64 = (reader.result as string).split(',')[1];
                          sessionPromise.then(s => s.sendRealtimeInput({ media: { data: base64, mimeType: 'image/jpeg' } }));
                        };
                        reader.readAsDataURL(blob);
                      }
                    }, 'image/jpeg', 0.4);
                  }
                }
              }, 1000);
            },
            onmessage: async (message: LiveServerMessage) => {
              const audioB64 = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
              if (audioB64 && audioContextOutRef.current) {
                setIsModelSpeaking(true);
                const ctx = audioContextOutRef.current;
                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                const buffer = await decodeAudioData(decode(audioB64), ctx, 24000, 1);
                const source = ctx.createBufferSource();
                source.buffer = buffer;
                source.connect(ctx.destination);
                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += buffer.duration;
                sourcesRef.current.add(source);
                source.onended = () => {
                  sourcesRef.current.delete(source);
                  if (sourcesRef.current.size === 0) setIsModelSpeaking(false); 
                };
              }

              if (message.serverContent?.outputTranscription) {
                setTranscription(message.serverContent.outputTranscription.text);
              }

              if (message.serverContent?.interrupted) {
                sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
                sourcesRef.current.clear();
                setIsModelSpeaking(false); 
              }
            },
            onclose: onEndCall,
            onerror: () => setStatus('SIGNAL_ERROR')
          },
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
            systemInstruction: SYSTEM_INSTRUCTION + " Sening ko'rinishing: Vermeil uslubida, uzun magenta sochlar, oltinrang ko'zlar, sho'x ifoda. Rasmda faqat bir kishi bo'lishi shart.",
            outputAudioTranscription: {},
            inputAudioTranscription: {}
          }
        });
        sessionRef.current = await sessionPromise;
      } catch (err) { onEndCall(); }
    };

    startLiveSession();
    const timer = setInterval(() => setCallDuration(p => p + 1), 1000);
    return () => {
      clearInterval(timer);
      if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
      sessionRef.current?.close();
      audioContextInRef.current?.close(); audioContextOutRef.current?.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col font-['Exo_2'] overflow-hidden">
      <canvas ref={canvasRef} className="hidden" />
      
      {/* Lumina (Main View) */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
        style={{ 
          backgroundImage: `url(${avatarUrl || 'https://picsum.photos/1200/1200'})`,
          filter: isModelSpeaking ? 'scale(1.05) saturate(1.1)' : 'scale(1) saturate(1)',
        }} 
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30"></div>
      </div>

      {/* Header */}
      <div className="absolute top-10 w-full flex flex-col items-center z-50">
        <div className="bg-black/40 backdrop-blur-2xl px-10 py-4 rounded-full border border-white/10 flex flex-col items-center shadow-2xl">
          <span className="text-white font-black text-2xl tracking-tighter uppercase italic">Lumina</span>
          <div className="flex items-center gap-2 mt-1">
            <div className={`w-2.5 h-2.5 rounded-full ${status === 'LIVE' ? 'bg-green-500 shadow-[0_0_12px_#22c55e]' : 'bg-red-500 animate-pulse'}`}></div>
            <span className="text-white/60 font-mono text-xs font-bold tracking-widest">{formatTime(callDuration)}</span>
          </div>
        </div>
      </div>

      {/* Dynamic Voice Waveform */}
      <div className="absolute bottom-44 left-0 w-full flex items-center justify-center gap-1.5 h-24 px-12 z-30 pointer-events-none">
        {waveHeights.map((h, i) => (
          <div 
            key={i} 
            className={`w-2 rounded-full transition-all duration-150 ${isModelSpeaking ? 'bg-pink-500 shadow-[0_0_20px_#ec4899]' : 'bg-white/10'}`} 
            style={{ 
              height: `${h}%`,
              opacity: isModelSpeaking ? 1 : 0.3
            }}
          ></div>
        ))}
      </div>

      {/* Transcription */}
      {transcription && (
        <div className="absolute bottom-60 left-1/2 -translate-x-1/2 w-[85%] max-w-sm z-40">
           <div className="bg-black/80 backdrop-blur-2xl p-6 rounded-[2.5rem] border border-white/10 shadow-2xl">
             <p className="text-white text-md text-center font-medium italic leading-relaxed">"{transcription}"</p>
           </div>
        </div>
      )}

      {/* User PiP */}
      <div className="absolute top-32 right-8 w-32 h-44 bg-black rounded-3xl border border-white/20 overflow-hidden shadow-2xl z-40 ring-1 ring-white/10">
        <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover grayscale brightness-110" />
      </div>

      {/* Controls */}
      <div className="absolute bottom-0 w-full pb-16 pt-10 px-12 flex justify-around items-center bg-gradient-to-t from-black via-black/90 to-transparent z-50">
        <button 
          onClick={() => setIsMuted(!isMuted)} 
          className={`w-18 h-18 rounded-full backdrop-blur-3xl border border-white/10 flex items-center justify-center text-3xl transition-all ${isMuted ? 'bg-red-500/40 border-red-500/50' : 'bg-white/5 hover:bg-white/10'}`}
        >
          {isMuted ? '🔇' : '🎙️'}
        </button>

        <button 
          onClick={onEndCall} 
          className="w-22 h-22 rounded-full bg-red-600 flex items-center justify-center shadow-[0_0_40px_rgba(220,38,38,0.5)] hover:scale-110 active:scale-95 transition-all border-4 border-white/20"
        >
          <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <button 
          onClick={() => { setIsCameraFront(!isCameraFront); setupCamera(); }} 
          className="w-18 h-18 rounded-full backdrop-blur-3xl bg-white/5 border border-white/10 flex items-center justify-center text-3xl hover:bg-white/10 transition-all"
        >
          🔄
        </button>
      </div>
    </div>
  );
};

export default VideoCallOverlay;
